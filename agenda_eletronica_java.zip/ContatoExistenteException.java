public class ContatoExistenteException extends Exception {
    public ContatoExistenteException(String mensagem) {
        super(mensagem);
    }
}
