# Agenda Eletrônica em Java

Aplicação desenvolvida para a Webquest 3 de Programação II.

## Funcionalidades
- CRUD de contatos
- Ordenação
- Busca por domínio
- CSV salvar/carregar

## Execução
javac *.java
java AgendaApplication

## Integrantes
Adicione aqui os nomes do grupo.
